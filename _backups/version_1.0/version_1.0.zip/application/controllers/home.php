<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {

        parent::__construct();
        
        $this->load->model('categories_model');
        $this->load->model('products_model');

    }

	public function index(){

		//$this->load->config('settings');
		//var_dump($this->config->item('tables'));
		
		$data['categories'] = $this->categories_model->get_active_data();
		$data['products'] = $this->products_model->get_active_limited_data();

		$this->load->view('home', $data);

	}


}
