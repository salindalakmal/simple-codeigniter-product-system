<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products extends CI_Controller {

	public $data;

	public function __construct() {
	
        parent::__construct();
        $this->load->model('categories_model');
        $this->load->model('products_model');
        $this->data['categories'] = $this->categories_model->get_active_data();

    }

	public function index(){
		
		$this->data['products'] = $this->products_model->get_active_data();
		$this->load->view('products', $this->data);

	}

	public function category_name_by_id($id){
		return $this->categories_model->get_name_by_id($id);
	}

	public function category($category = '', $product = ''){

		if($category){

			if(!$product){

				$cate_id =  $this->categories_model->get_id_by_name($category);
				$this->data['products'] = $this->products_model->get_data_by_category($cate_id);

				


				$this->load->view('products', $this->data);

			} else{

				echo $product;
				$this->load->view('view_product', $this->data);

			}	

		} else {

			$this->data['products'] = "";
			$this->load->view('products', $this->data);

		}

	}

}
