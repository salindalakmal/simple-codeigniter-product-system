<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Products_model extends CI_Model{
	
	public $table;

	function __construct(){

		parent::__construct();

		$this->table = $this->config->item('tables')['products'];

	}

	function get_active_data(){

		$this->db->where('status', 1);
		$query = $this->db->get($this->table);

		if($query->num_rows() > 0){
			return $query->result();
		} else{
			return false;
		}

	}

	function get_active_limited_data(){

		$this->db->where('status', 1);
		$this->db->limit(8);
		$query = $this->db->get($this->table);

		if($query->num_rows() > 0){
			return $query->result();
		} else{
			return false;
		}

	}

	function get_data_by_category($cat_id){

		$this->db->where('status', 1);
		$this->db->where('category', $cat_id);
		$query = $this->db->get($this->table);

		if($query->num_rows() > 0){
			return $query->result();
		} else{
			return false;
		}
		
	}


}

