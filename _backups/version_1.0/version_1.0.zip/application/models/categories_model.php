<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Categories_model extends CI_Model {
	
	public $table;

	function __construct(){

		parent::__construct();

		$this->table = $this->config->item('tables')['categories'];
		//var_dump($this->table);

	}

	function get_active_data(){

		$this->db->where('status', 1);
		$query = $this->db->get($this->table);
		//echo $this->db->last_query();
		//var_dump($query->result());

		if($query->num_rows() > 0){
			return $query->result();
		} else{
			return false;
		}
		
	}

	function get_id_by_name($name = ""){

		$this->db->where('status', 1);
		$this->db->where('name', $name);
		$query = $this->db->get($this->table);

		if($query->num_rows() == 1){
			$row =  $query->row();
			return $row->id;
		} else{
			return false;
		}

	}

	function get_name_by_id($id){

		$this->db->select('name');
		$this->db->where('id', $id);
		echo $query = $this->db->get($this->table);



	}



}

